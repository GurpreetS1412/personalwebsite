import { site } from "../lib/site";

export function SiteFooter() {
  const items: { label: string; href: string }[] = [
    { label: "GitHub", href: site.links.github },
    { label: "LinkedIn", href: site.links.linkedin },
    { label: "Twitter", href: site.links.twitter },
    { label: "Email", href: site.email ? `mailto:${site.email}` : "" },
  ].filter((item) => item.href);

  return (
    <footer
      id="contact"
      className="flex flex-col items-start justify-between gap-12 border-t border-zinc-100 py-24 md:flex-row"
    >
      <div>
        <h2 className="mb-4 text-2xl font-medium">Let&apos;s connect</h2>
        <p className="text-zinc-500">Open to learning, collaborating and building things.</p>
      </div>
      <div className="flex gap-8 text-sm font-medium text-zinc-500">
        {items.map((item) => (
          <a
            key={item.label}
            href={item.href}
            target={item.href.startsWith("mailto:") ? undefined : "_blank"}
            rel="noopener noreferrer"
            className="transition-colors hover:text-black"
          >
            {item.label}
          </a>
        ))}
      </div>
    </footer>
  );
}
