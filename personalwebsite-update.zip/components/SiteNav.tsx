import Link from "next/link";
import { site } from "../lib/site";

export function SiteNav({ active }: { active: "work" | "about" }) {
  const base = "transition-colors hover:text-black";
  const on = "text-black font-medium";
  const off = "text-zinc-500";

  return (
    <nav className="flex items-center justify-between py-8 mb-12">
      <Link href="/" className="text-sm font-medium tracking-tight">
        {site.brand}
      </Link>
      <div className="flex gap-8 text-sm">
        <Link href="/#work" className={`${base} ${active === "work" ? on : off}`}>
          Work
        </Link>
        <Link href="/about" className={`${base} ${active === "about" ? on : off}`}>
          About
        </Link>
        <Link href="/#contact" className={`${base} ${off}`}>
          Contact
        </Link>
      </div>
    </nav>
  );
}
