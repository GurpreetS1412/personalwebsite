# Personal website

My personal site, built with Next.js, TypeScript, Tailwind CSS and Framer Motion.

## Editing the content

Almost everything you'd want to change lives in one file: `lib/site.ts`
(name, tagline, location, email, social links and the project list).
Any value left as `""` is simply not shown.

## Running locally

```bash
npm install
npm run dev
```

Then open http://localhost:3000.

## Deploying

Pushing to the `main` branch redeploys the site on Vercel.
