// Single place to edit your personal details.
// Leave a value as an empty string "" and it simply won't be shown on the site.

export const site = {
  name: "Gurpreet",
  brand: "GURPREET",
  tagline:
    "Student and self-taught developer who learns by building small, useful web tools.",
  location: "", // e.g. "Punjab, India"  (shown in the hero when filled in)
  email: "", // e.g. "you@example.com"  (adds an Email link when filled in)
  links: {
    github: "https://github.com/GurpreetS1412",
    linkedin: "", // e.g. "https://www.linkedin.com/in/your-handle"
    twitter: "", // e.g. "https://x.com/your-handle"
  },
};

export type Project = {
  title: string;
  category: string;
  description: string;
  tags: string[];
  repo: string;
  live?: string; // add a deployed URL here and a "View live" link appears
};

export const projects: Project[] = [
  {
    title: "chemAlert",
    category: "Web app",
    description:
      "A searchable catalogue of everyday products and the chemicals in them, with categories, product pages, safety highlights and a form to add new products. Built with Next.js and TypeScript, with a light/dark theme and a mobile-friendly layout.",
    tags: ["Next.js", "TypeScript", "Tailwind CSS"],
    repo: "https://github.com/GurpreetS1412/chemAlert",
  },
  {
    title: "safer",
    category: "Web app",
    description:
      "An earlier take on the same idea, written in plain JavaScript with no framework. It tracks real-world products and their ingredients, links them to a chemicals dataset, and lets you add products by pasting JSON.",
    tags: ["JavaScript", "HTML", "CSS"],
    repo: "https://github.com/GurpreetS1412/safer",
  },
];

export const learning = [
  "Python fundamentals",
  "Building apps quickly with AI-assisted tools",
  "How large language models work (following an open-source LLM course)",
];
