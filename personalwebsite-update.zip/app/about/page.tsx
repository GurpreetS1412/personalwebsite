import { Reveal } from "../../components/Reveal";
import { SiteFooter } from "../../components/SiteFooter";
import { SiteNav } from "../../components/SiteNav";
import { learning, site } from "../../lib/site";

export const metadata = {
  title: `About · ${site.name}`,
  description: `About ${site.name}`,
};

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-white p-6 font-sans text-[#111] md:px-12 lg:px-24">
      <SiteNav active="about" />

      <div className="mx-auto max-w-4xl">
        <Reveal className="mb-32">
          <h1 className="mb-8 text-3xl font-medium leading-tight tracking-tight md:text-5xl">
            I&apos;m {site.name}, a student who learns by building.
          </h1>
          <div className="max-w-2xl space-y-5 text-lg leading-relaxed text-zinc-500">
            <p>
              I got into programming through tinkering: customising my tools, repurposing old
              hardware, and trying out whatever new app or framework looks interesting. I prefer a
              fast, practical route, so I start with a real project and learn what I need along
              the way.
            </p>
            <p>
              So far that has meant web apps like chemAlert, a product and ingredient safety
              catalogue, and a lot of experimenting with AI tools to build and ship faster.
            </p>
          </div>
        </Reveal>

        <Reveal className="mb-32 grid grid-cols-1 gap-16 md:grid-cols-2">
          <div>
            <h2 className="mb-6 text-xs font-bold uppercase tracking-widest text-zinc-400">
              Currently learning
            </h2>
            <ul className="space-y-3 text-zinc-600">
              {learning.map((item) => (
                <li key={item} className="border-b border-zinc-100 pb-3">
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2 className="mb-6 text-xs font-bold uppercase tracking-widest text-zinc-400">
              Tools I use
            </h2>
            <ul className="space-y-3 text-zinc-600">
              {["Next.js & TypeScript", "Python", "VS Code & Cursor", "Obsidian"].map((item) => (
                <li key={item} className="border-b border-zinc-100 pb-3">
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </Reveal>

        <SiteFooter />
      </div>
    </main>
  );
}
