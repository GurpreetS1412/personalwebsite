import { Reveal } from "../components/Reveal";
import { SiteFooter } from "../components/SiteFooter";
import { SiteNav } from "../components/SiteNav";
import { projects, site } from "../lib/site";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-white p-6 font-sans text-[#111] md:px-12 lg:px-24">
      <SiteNav active="work" />

      <header className="mb-32 mt-12">
        <Reveal className="max-w-3xl">
          <p className="mb-6 text-sm text-zinc-400">
            Hi, I&apos;m {site.name}
            {site.location ? ` · ${site.location}` : ""}
          </p>
          <h1 className="mb-8 text-4xl font-medium leading-tight tracking-tight text-black md:text-6xl">
            {site.tagline}
          </h1>
          <p className="max-w-xl text-lg leading-relaxed text-zinc-500">
            I like tinkering with tech, picking up new tools fast, and turning ideas into
            working apps. Below are a couple of things I&apos;ve built.
          </p>
        </Reveal>
      </header>

      <section id="work" className="mb-32 scroll-mt-12">
        <h2 className="mb-12 text-xs font-semibold uppercase tracking-widest text-zinc-400">
          Selected Work
        </h2>

        <div className="space-y-32">
          {projects.map((project, i) => (
            <Reveal
              key={project.title}
              className="grid grid-cols-1 items-start gap-12 md:grid-cols-2"
            >
              <a
                href={project.repo}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`${project.title} on GitHub`}
                className={`group flex aspect-[4/3] items-center justify-center overflow-hidden rounded-sm bg-zinc-100 ${
                  i % 2 === 1 ? "md:order-2" : ""
                }`}
              >
                <span className="select-none text-5xl font-medium tracking-tight text-zinc-300 transition-transform duration-700 ease-in-out group-hover:scale-110 md:text-6xl">
                  {project.title}
                </span>
              </a>

              <div
                className={`flex flex-col justify-center pt-4 ${
                  i % 2 === 1 ? "md:order-1" : ""
                }`}
              >
                <span className="mb-2 text-xs uppercase tracking-wider text-zinc-400">
                  {project.category}
                </span>
                <h3 className="mb-4 text-2xl font-medium text-black">{project.title}</h3>
                <p className="mb-6 max-w-md leading-relaxed text-zinc-500">
                  {project.description}
                </p>
                <ul className="mb-8 flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <li
                      key={tag}
                      className="rounded-full border border-zinc-200 px-3 py-1 text-xs text-zinc-500"
                    >
                      {tag}
                    </li>
                  ))}
                </ul>
                <div className="flex gap-6 text-sm font-medium">
                  {project.live && (
                    <a
                      href={project.live}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-fit border-b border-black pb-1 transition-all hover:border-zinc-500 hover:text-zinc-500"
                    >
                      View live →
                    </a>
                  )}
                  <a
                    href={project.repo}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-fit border-b border-black pb-1 transition-all hover:border-zinc-500 hover:text-zinc-500"
                  >
                    View code →
                  </a>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <SiteFooter />
    </main>
  );
}
