import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { site } from "../lib/site";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: `${site.name} · Personal Website`,
  description: site.tagline,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-white text-[#111] antialiased`}>
        {children}
      </body>
    </html>
  );
}
